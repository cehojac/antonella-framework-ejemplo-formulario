<?php
namespace EJFORM;

class Init
{
    public function __construct()
    {

    }

    public function index()
    {

    }
}
