<?php
namespace EJFORM;

class Desactivate
{
    /*
    *
    */
    public function index()
    {

    }
}
