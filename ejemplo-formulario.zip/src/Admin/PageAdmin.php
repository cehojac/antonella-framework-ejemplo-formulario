<?php

namespace EJFORM\Admin;

class PageAdmin extends Admin
{
    function index()
    {

    }

}
